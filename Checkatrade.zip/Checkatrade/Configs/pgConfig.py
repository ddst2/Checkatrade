# -*- coding: utf-8 -*-
"""
Created on Mon Feb 28 18:20:16 2022

@author: damba
"""

PG_PARAM_DICT = {
    "host"      : "localhost",
    "database"  : "postgres",
    "user"      : "postgres",
    "password"  : "postgres",
    "port"      : 5432
}

SCHEMA_NAME = 'swapi_checkatrade'