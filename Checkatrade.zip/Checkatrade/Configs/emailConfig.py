# -*- coding: utf-8 -*-
"""
Created on Tue Mar  1 07:59:35 2022

@author: damba
"""

SMTP_SERVER = 'localhost'
EMAIL_FROM = 'checkatrade@info.com'
EMAIL_TO = 'samantaraydd@gmail.com'